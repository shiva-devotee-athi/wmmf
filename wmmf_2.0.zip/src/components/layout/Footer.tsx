import Link from "next/link";
import { Phone, Mail, MapPin, icons } from "lucide-react";
import Image from "next/image";
import { siteConfig } from "@/data/site";

const pageLinks = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "The Sport", href: "/history-of-the-sport" },
  { label: "News", href: "/news" },
  { label: "Members", href: "/members" },
  { label: "Contact", href: "/contact" },
];

const governanceLinks = [
  { label: "Statutes", href: "/statutes" },
  { label: "Competition Rules", href: "/rules-regulations" },
  { label: "Referee Guidelines", href: "/wmmf-referee-rules-guidlines" },
  { label: "Privacy Policy", href: "/privacy-policy" },
];

const socials = [
  {
    label: "Facebook",
    href: "#",
    Icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 666.667 666.667"
        className="h-4 w-4"
      >
        <defs>
          <clipPath id="a" clipPathUnits="userSpaceOnUse">
            <path d="M0 700h700V0H0Z" />
          </clipPath>
        </defs>
        <g
          clipPath="url(#a)"
          transform="matrix(1.33333 0 0 -1.33333 -133.333 800)"
        >
          <path
            d="M0 0c0 138.071-111.929 250-250 250S-500 138.071-500 0c0-117.245 80.715-215.622 189.606-242.638v166.242h-51.552V0h51.552v32.919c0 85.092 38.508 124.532 122.048 124.532 15.838 0 43.167-3.105 54.347-6.211V81.986c-5.901.621-16.149.932-28.882.932-40.993 0-56.832-15.528-56.832-55.9V0h81.659l-14.028-76.396h-67.631v-171.773C-95.927-233.218 0-127.818 0 0"
            style={{
              fill: "#0866ff",
              fillOpacity: 1,
              fillRule: "nonzero",
              stroke: "none",
            }}
            transform="translate(600 350)"
          />
          <path
            d="m0 0 14.029 76.396H-67.63v27.019c0 40.372 15.838 55.899 56.831 55.899 12.733 0 22.981-.31 28.882-.931v69.253c-11.18 3.106-38.509 6.212-54.347 6.212-83.539 0-122.048-39.441-122.048-124.533V76.396h-51.552V0h51.552v-166.242a250.559 250.559 0 0 1 60.394-7.362c10.254 0 20.358.632 30.288 1.831V0Z"
            style={{
              fill: "#fff",
              fillOpacity: 1,
              fillRule: "nonzero",
              stroke: "none",
            }}
            transform="translate(447.918 273.604)"
          />
        </g>
      </svg>
    ),
  },
  {
    label: "LinkedIn",
    href: "#",
    Icon: (
      <svg
        width="256"
        height="256"
        preserveAspectRatio="xMidYMid"
        viewBox="0 0 256 256"
        className="h-4 w-4"
      >
        <path
          d="M218.123 218.127h-37.931v-59.403c0-14.165-.253-32.4-19.728-32.4-19.756 0-22.779 15.434-22.779 31.369v60.43h-37.93V95.967h36.413v16.694h.51a39.907 39.907 0 0 1 35.928-19.733c38.445 0 45.533 25.288 45.533 58.186l-.016 67.013ZM56.955 79.27c-12.157.002-22.014-9.852-22.016-22.009-.002-12.157 9.851-22.014 22.008-22.016 12.157-.003 22.014 9.851 22.016 22.008A22.013 22.013 0 0 1 56.955 79.27m18.966 138.858H37.95V95.967h37.97v122.16ZM237.033.018H18.89C8.58-.098.125 8.161-.001 18.471v219.053c.122 10.315 8.576 18.582 18.89 18.474h218.144c10.336.128 18.823-8.139 18.966-18.474V18.454c-.147-10.33-8.635-18.588-18.966-18.453"
          fill="#0A66C2"
        />
      </svg>
    ),
  },
  {
    label: "Instagram",
    href: "#",
    Icon: (
      <svg
        xmlnsXlink="http://www.w3.org/1999/xlink"
        viewBox="0 0 264.583 264.583"
        className="h-4 w-4"
      >
        <defs>
          <radialGradient
            xlinkHref="#a"
            id="f"
            cx="158.429"
            cy="578.088"
            r="52.352"
            fx="158.429"
            fy="578.088"
            gradientTransform="matrix(0 -4.03418 4.28018 0 -2332.227 942.236)"
            gradientUnits="userSpaceOnUse"
          />
          <radialGradient
            xlinkHref="#b"
            id="g"
            cx="172.615"
            cy="600.692"
            r="65"
            fx="172.615"
            fy="600.692"
            gradientTransform="matrix(.67441 -1.16203 1.51283 .87801 -814.366 -47.835)"
            gradientUnits="userSpaceOnUse"
          />
          <radialGradient
            xlinkHref="#c"
            id="h"
            cx="144.012"
            cy="51.337"
            r="67.081"
            fx="144.012"
            fy="51.337"
            gradientTransform="matrix(-2.3989 .67549 -.23008 -.81732 464.996 -26.404)"
            gradientUnits="userSpaceOnUse"
          />
          <radialGradient
            xlinkHref="#d"
            id="e"
            cx="199.788"
            cy="628.438"
            r="52.352"
            fx="199.788"
            fy="628.438"
            gradientTransform="matrix(-3.10797 .87652 -.6315 -2.23914 1345.65 1374.198)"
            gradientUnits="userSpaceOnUse"
          />
          <linearGradient id="d">
            <stop offset="0" stopColor="#ff005f" />
            <stop offset="1" stopColor="#fc01d8" />
          </linearGradient>
          <linearGradient id="c">
            <stop offset="0" stopColor="#780cff" />
            <stop offset="1" stopColor="#820bff" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="b">
            <stop offset="0" stopColor="#fc0" />
            <stop offset="1" stopColor="#fc0" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="a">
            <stop offset="0" stopColor="#fc0" />
            <stop offset=".124" stopColor="#fc0" />
            <stop offset=".567" stopColor="#fe4a05" />
            <stop offset=".694" stopColor="#ff0f3f" />
            <stop offset="1" stopColor="#fe0657" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          fill="url(#e)"
          d="M204.15 18.143c-55.23 0-71.383.057-74.523.317-11.334.943-18.387 2.728-26.07 6.554-5.922 2.942-10.592 6.351-15.201 11.13-8.394 8.716-13.481 19.439-15.323 32.184-.895 6.188-1.156 7.45-1.209 39.056-.02 10.536 0 24.4 0 42.999 0 55.2.062 71.341.326 74.476.916 11.032 2.645 17.973 6.308 25.565 7 14.533 20.37 25.443 36.12 29.514 5.453 1.404 11.476 2.178 19.208 2.544 3.277.142 36.669.244 70.081.244 33.413 0 66.826-.04 70.02-.203 8.954-.422 14.153-1.12 19.901-2.606 15.852-4.09 28.977-14.838 36.12-29.575 3.591-7.409 5.412-14.614 6.236-25.07.18-2.28.255-38.626.255-74.924 0-36.304-.082-72.583-.26-74.863-.835-10.625-2.656-17.77-6.364-25.32-3.042-6.182-6.42-10.799-11.324-15.519-8.752-8.361-19.455-13.45-32.21-15.29-6.18-.894-7.41-1.158-39.033-1.213z"
          transform="translate(-71.816 -18.143)"
        />
        <path
          fill="url(#f)"
          d="M204.15 18.143c-55.23 0-71.383.057-74.523.317-11.334.943-18.387 2.728-26.07 6.554-5.922 2.942-10.592 6.351-15.201 11.13-8.394 8.716-13.481 19.439-15.323 32.184-.895 6.188-1.156 7.45-1.209 39.056-.02 10.536 0 24.4 0 42.999 0 55.2.062 71.341.326 74.476.916 11.032 2.645 17.973 6.308 25.565 7 14.533 20.37 25.443 36.12 29.514 5.453 1.404 11.476 2.178 19.208 2.544 3.277.142 36.669.244 70.081.244 33.413 0 66.826-.04 70.02-.203 8.954-.422 14.153-1.12 19.901-2.606 15.852-4.09 28.977-14.838 36.12-29.575 3.591-7.409 5.412-14.614 6.236-25.07.18-2.28.255-38.626.255-74.924 0-36.304-.082-72.583-.26-74.863-.835-10.625-2.656-17.77-6.364-25.32-3.042-6.182-6.42-10.799-11.324-15.519-8.752-8.361-19.455-13.45-32.21-15.29-6.18-.894-7.41-1.158-39.033-1.213z"
          transform="translate(-71.816 -18.143)"
        />
        <path
          fill="url(#g)"
          d="M204.15 18.143c-55.23 0-71.383.057-74.523.317-11.334.943-18.387 2.728-26.07 6.554-5.922 2.942-10.592 6.351-15.201 11.13-8.394 8.716-13.481 19.439-15.323 32.184-.895 6.188-1.156 7.45-1.209 39.056-.02 10.536 0 24.4 0 42.999 0 55.2.062 71.341.326 74.476.916 11.032 2.645 17.973 6.308 25.565 7 14.533 20.37 25.443 36.12 29.514 5.453 1.404 11.476 2.178 19.208 2.544 3.277.142 36.669.244 70.081.244 33.413 0 66.826-.04 70.02-.203 8.954-.422 14.153-1.12 19.901-2.606 15.852-4.09 28.977-14.838 36.12-29.575 3.591-7.409 5.412-14.614 6.236-25.07.18-2.28.255-38.626.255-74.924 0-36.304-.082-72.583-.26-74.863-.835-10.625-2.656-17.77-6.364-25.32-3.042-6.182-6.42-10.799-11.324-15.519-8.752-8.361-19.455-13.45-32.21-15.29-6.18-.894-7.41-1.158-39.033-1.213z"
          transform="translate(-71.816 -18.143)"
        />
        <path
          fill="url(#h)"
          d="M204.15 18.143c-55.23 0-71.383.057-74.523.317-11.334.943-18.387 2.728-26.07 6.554-5.922 2.942-10.592 6.351-15.201 11.13-8.394 8.716-13.481 19.439-15.323 32.184-.895 6.188-1.156 7.45-1.209 39.056-.02 10.536 0 24.4 0 42.999 0 55.2.062 71.341.326 74.476.916 11.032 2.645 17.973 6.308 25.565 7 14.533 20.37 25.443 36.12 29.514 5.453 1.404 11.476 2.178 19.208 2.544 3.277.142 36.669.244 70.081.244 33.413 0 66.826-.04 70.02-.203 8.954-.422 14.153-1.12 19.901-2.606 15.852-4.09 28.977-14.838 36.12-29.575 3.591-7.409 5.412-14.614 6.236-25.07.18-2.28.255-38.626.255-74.924 0-36.304-.082-72.583-.26-74.863-.835-10.625-2.656-17.77-6.364-25.32-3.042-6.182-6.42-10.799-11.324-15.519-8.752-8.361-19.455-13.45-32.21-15.29-6.18-.894-7.41-1.158-39.033-1.213z"
          transform="translate(-71.816 -18.143)"
        />
        <path
          fill="#fff"
          d="M132.345 33.973c-26.716 0-30.07.117-40.563.594-10.472.48-17.62 2.136-23.876 4.567-6.47 2.51-11.958 5.87-17.426 11.335-5.472 5.464-8.834 10.948-11.354 17.412-2.44 6.252-4.1 13.397-4.57 23.858-.47 10.486-.593 13.838-.593 40.535 0 26.697.119 30.037.594 40.522.482 10.465 2.14 17.609 4.57 23.859 2.515 6.465 5.876 11.95 11.346 17.414 5.466 5.468 10.955 8.834 17.42 11.345 6.26 2.431 13.41 4.088 23.881 4.567 10.493.477 13.844.594 40.559.594 26.719 0 30.061-.117 40.555-.594 10.472-.48 17.63-2.136 23.888-4.567 6.468-2.51 11.948-5.877 17.414-11.345 5.472-5.464 8.834-10.949 11.354-17.412 2.419-6.252 4.079-13.398 4.57-23.858.472-10.486.595-13.828.595-40.525s-.123-30.047-.594-40.533c-.492-10.465-2.152-17.608-4.57-23.858-2.521-6.466-5.883-11.95-11.355-17.414-5.472-5.468-10.944-8.827-17.42-11.335-6.271-2.431-13.424-4.088-23.897-4.567-10.493-.477-13.834-.594-40.558-.594zm-8.825 17.715c2.62-.004 5.542 0 8.825 0 26.266 0 29.38.094 39.752.565 9.591.438 14.797 2.04 18.264 3.385 4.591 1.782 7.864 3.912 11.305 7.352 3.443 3.44 5.575 6.717 7.362 11.305 1.346 3.46 2.951 8.663 3.388 18.247.47 10.363.573 13.475.573 39.71 0 26.233-.102 29.346-.573 39.709-.44 9.584-2.042 14.786-3.388 18.247-1.783 4.587-3.919 7.854-7.362 11.292-3.443 3.441-6.712 5.57-11.305 7.352-3.463 1.352-8.673 2.95-18.264 3.388-10.37.47-13.486.573-39.752.573-26.268 0-29.38-.102-39.751-.573-9.592-.443-14.797-2.044-18.267-3.39-4.59-1.781-7.87-3.911-11.313-7.352-3.443-3.44-5.574-6.709-7.362-11.298-1.346-3.461-2.95-8.663-3.387-18.247-.472-10.363-.566-13.476-.566-39.726s.094-29.347.566-39.71c.438-9.584 2.04-14.786 3.387-18.25 1.783-4.588 3.919-7.865 7.362-11.305 3.443-3.441 6.722-5.57 11.313-7.357 3.468-1.351 8.675-2.949 18.267-3.389 9.075-.41 12.592-.532 30.926-.553zm61.337 16.322c-6.518 0-11.805 5.277-11.805 11.792 0 6.512 5.287 11.796 11.805 11.796 6.517 0 11.804-5.284 11.804-11.796 0-6.513-5.287-11.796-11.805-11.796zm-52.512 13.782c-27.9 0-50.519 22.603-50.519 50.482 0 27.879 22.62 50.471 50.52 50.471s50.51-22.592 50.51-50.471c0-27.879-22.613-50.482-50.513-50.482zm0 17.715c18.11 0 32.792 14.67 32.792 32.767 0 18.096-14.683 32.767-32.792 32.767-18.11 0-32.791-14.671-32.791-32.767 0-18.098 14.68-32.767 32.791-32.767z"
        />
      </svg>
    ),
  },
  {
    label: "Twitter",
    href: "#",
    Icon: (
      <svg fill="#000000" role="img" viewBox="0 0 24 24" className="h-4 w-4">
        <title>X</title>
        <path d="M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z" />
      </svg>
    ),
  },
  {
    label: "YouTube",
    href: "#",
    Icon: (
      <svg
        preserveAspectRatio="xMidYMid"
        viewBox="0 0 256 180"
        className="h-4 w-4"
      >
        <path
          fill="red"
          d="M250.346 28.075A32.18 32.18 0 0 0 227.69 5.418C207.824 0 127.87 0 127.87 0S47.912.164 28.046 5.582A32.18 32.18 0 0 0 5.39 28.24c-6.009 35.298-8.34 89.084.165 122.97a32.18 32.18 0 0 0 22.656 22.657c19.866 5.418 99.822 5.418 99.822 5.418s79.955 0 99.82-5.418a32.18 32.18 0 0 0 22.657-22.657c6.338-35.348 8.291-89.1-.164-123.134Z"
        />
        <path fill="#FFF" d="m102.421 128.06 66.328-38.418-66.328-38.418z" />
      </svg>
    ),
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-slate-800/80 bg-secondary-900 pt-12 pb-8">
      <div className="mx-auto w-full max-w-[1280px] px-4 xl:px-0">
        <div className="flex flex-col justify-between gap-10 sm:px-[18px] md:flex-row md:gap-6 md:px-10">
          {/* Brand */}
          <div className="md:w-[300px]">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/images/logos/logo.png"
                alt="logo"
                width={60}
                height={60}
                className="w-14 h-14 md:w-18 md:h-18"
              />
            </Link>
            <p className="mt-[18px] font-body text-[14.5px] font-normal leading-relaxed text-white/80">
              The international governing body dedicated to developing and
              promoting the world&apos;s fastest and most accessible small-sided
              football format worldwide.
            </p>
            <div className="mt-[18px] flex gap-3">
              {socials.map(({ label, href, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition-transform duration-150 hover:scale-110 hover:bg-white/20"
                >
                  {Icon}
                </a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div className="md:w-[300px]">
            <div className="flex">
              <div className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full bg-white/10">
                <Phone className="h-[18px] w-[18px] text-white" />
              </div>
              <div className="ml-[16px]">
                <a
                  href={`tel:${siteConfig.phone}`}
                  className="font-body text-[14px] font-medium text-white"
                >
                  {siteConfig.phone}
                </a>
                <p className="font-body text-[12px] font-medium text-white/60">
                  WhatsApp Number
                </p>
              </div>
            </div>

            <div className="mt-[20px] flex">
              <div className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full bg-white/10">
                <Mail className="h-[16px] w-[16px] text-white" />
              </div>
              <div className="ml-[16px]">
                <a
                  href={`mailto:${siteConfig.primary_email}`}
                  className="font-body text-[14px] font-medium text-white"
                >
                  {siteConfig.primary_email}, {siteConfig.secondary_email}
                </a>
                <p className="font-body text-[12px] font-medium text-white/60">
                  Support Email
                </p>
              </div>
            </div>

            <div className="mt-[20px] flex">
              <div className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full bg-white/10">
                <MapPin className="h-[16px] w-[16px] text-white" />
              </div>
              <div className="ml-[16px]">
                <p className="font-body text-[14px] font-medium text-white">
                  {siteConfig.address}
                </p>
                <p className="font-body text-[12px] font-medium text-white/60">
                  Our Office
                </p>
              </div>
            </div>
          </div>

          {/* Link columns */}
          <div className="flex w-full flex-col justify-between gap-8 text-white sm:flex-row md:max-w-[341px]">
            <div>
              <p className="font-body text-[16px] font-semibold text-white">
                Pages
              </p>
              <ul>
                {pageLinks.map((link) => (
                  <li key={link.href} className="mt-[13px]">
                    <Link
                      href={link.href}
                      className="font-body text-[14.5px] font-normal text-white/80 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="font-body text-[16px] font-semibold text-white">
                Governance
              </p>
              <ul>
                {governanceLinks.map((link) => (
                  <li key={link.href} className="mt-[13px]">
                    <Link
                      href={link.href}
                      className="font-body text-[14.5px] font-normal text-white/80 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <hr className="mt-[30px] border-white/10" />
        <div className="flex items-center justify-center pb-8 pt-[9px] md:py-8">
          <p className="text-center font-body text-[11px] font-normal text-white/70 md:text-[12px]">
            © {new Date().getFullYear()} World Mini Mini Football. All Rights
            Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
